package com.kotlinviper.products.utilities


const val DATABASE_NAME = "products-db"
const val productS_DATA_FILENAME = "products.json"
const val product_KEY = "PRODUCT_KEY"